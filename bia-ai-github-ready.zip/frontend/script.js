
console.log("BIA-AI frontend cargado correctamente");
